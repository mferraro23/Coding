
Terms of Use

All files made available on http://www.psdchat.com are free for personal and commercial use, no attribution necessary. 

You are not allowed to re-sale or re-distribution the content available here. Further more you are not allowed to offer the resource available for download on your own site, if you would like to share the resources available here please link back to the original download page.

You are not permitted to make the resources found on Psd Chat available for distribution elsewhere �as is� without prior consent.

**********************

http://www.psdchat.com
info@psdchat.com

